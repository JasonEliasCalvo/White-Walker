using UnityEngine;


[CreateAssetMenu(fileName = "New DaggerAttack", menuName = "Combat/DaggerAttack")]
public class DaggerAttack : AttackBase
{
    public override AttackCategory category => AttackCategory.Dagger;
}