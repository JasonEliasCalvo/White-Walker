using UnityEngine;

[CreateAssetMenu(fileName = "NewFistKickAttack", menuName = "Combat/FistKickAttack")]
public class FistKickAttack : AttackBase
{
    public override AttackCategory category => AttackCategory.FistKick;
}