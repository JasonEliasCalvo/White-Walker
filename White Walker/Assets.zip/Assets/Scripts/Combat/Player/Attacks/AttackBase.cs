using System;
using System.Collections.Generic;
using UnityEngine;

public enum AttackCategory { Claw, Sword, Gun }

public abstract class AttackBase : ScriptableObject
{
    [Header("Attack Data")]
    [HideInInspector] public string uniqueID = Guid.NewGuid().ToString();
    public int id;
    public string attackName;             // Nombre visible
    public float damage;                  // Da�o que inflige
    public float duration;                // Cu�nto dura la animaci�n o ejecuci�n
    public int cost;                      // Cu�nto cuesta comprarlo
    public AttackCategory category;       // Tipo de ataque para combos
    public AnimationClip animation;       // Clip de animaci�n
    public List<EffectData> effects = new(); // Efectos especiales como stun, launcher, etc.
}
