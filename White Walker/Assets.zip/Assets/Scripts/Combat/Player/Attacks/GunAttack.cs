using UnityEngine;

[CreateAssetMenu(fileName = "New Shoot", menuName = "Combat/GunAttack")]
public class GunAttack : AttackBase
{
    public override AttackCategory category => AttackCategory.Gun;

}
