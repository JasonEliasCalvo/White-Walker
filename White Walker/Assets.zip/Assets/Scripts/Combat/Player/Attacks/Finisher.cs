using UnityEngine;

[CreateAssetMenu(fileName = "New Finisher", menuName = "Combat/Finisher")]
public class Finisher : AttackBase
{
    public bool stunnedOnly;

    public override AttackCategory category => AttackCategory.Finisher;
}
