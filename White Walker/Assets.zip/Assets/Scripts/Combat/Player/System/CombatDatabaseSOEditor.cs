using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

[CustomEditor(typeof(CombatDatabaseSO))]
public class CombatDatabaseSOEditor : Editor
{
    public override void OnInspectorGUI()
    {
        DrawDefaultInspector();

        if (GUILayout.Button("Update All Attacks"))
        {
            CombatDatabaseSO database = (CombatDatabaseSO)target;
            List<AttackBase> all = CombatManager.Instance.GetAllAttacks();

            EditorUtility.SetDirty(database);
            Debug.Log("All attacks list updated!");
        }
    }
}
