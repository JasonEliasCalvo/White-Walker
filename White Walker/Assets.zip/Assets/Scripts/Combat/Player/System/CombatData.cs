using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;


public class CombatData : MonoBehaviour
{
    [Header("Combat Database")]
    [SerializeField] private CombatDatabaseSO combatSO;

    private PlayerSaveData saveData;

    private Dictionary<AttackCategory, List<int>> unlockedAttacks;
    private Dictionary<AttackCategory, List<int>> equippedCombos;

    #region Initialization

    public void Initialize(PlayerSaveData data)
    {
        saveData = data;
        unlockedAttacks = new Dictionary<AttackCategory, List<int>>();
        equippedCombos = new Dictionary<AttackCategory, List<int>>();

        foreach (var attack in combatSO.allAttacks)
        {
            AttackCategory category = attack.category;
            if (!unlockedAttacks.ContainsKey(category))
                unlockedAttacks[category] = new List<int>();
            if (!equippedCombos.ContainsKey(category))
                equippedCombos[category] = new List<int>();
        }

        if (saveData.unlockData.unlockedAttacks != null)
        {
            foreach (var kvp in saveData.unlockData.unlockedAttacks)
            {
                unlockedAttacks[kvp.Key] = new List<int>(kvp.Value);
            }
        }

        if (saveData.comboData.equippedCombos != null)
        {
            foreach (var kvp in saveData.comboData.equippedCombos)
            {
                equippedCombos[kvp.Key] = new List<int>(kvp.Value);
            }
        }
    }

    private void UpdateSaveData()
    {
        saveData.unlockData.unlockedAttacks.Clear();
        saveData.comboData.equippedCombos.Clear();

        foreach (var kvp in unlockedAttacks)
        {
            saveData.unlockData.unlockedAttacks[kvp.Key] = new List<int>(kvp.Value);
        }

        foreach (var kvp in equippedCombos)
        {
            saveData.comboData.equippedCombos[kvp.Key] = new List<int>(kvp.Value);
        }
    }

    #endregion


    #region Accessors

    public List<AttackBase> GetUnlockedAttacks(AttackCategory category)
    {
        List<AttackBase> list = new List<AttackBase>();

        if (unlockedAttacks.TryGetValue(category, out List<int> ids))
        {
            foreach (var attack in CombatManager.Instance.GetAttacksByCategory(category))
            {
                if (ids.Contains(attack.id))
                    list.Add(attack);
            }
        }

        return list;
    }

    public List<int> GetUnlockedAttackIDs(AttackCategory category)
    {
        return unlockedAttacks.TryGetValue(category, out var ids)
            ? new List<int>(ids)
            : new List<int>();
    }

    public List<int> GetEquippedCombo(AttackCategory category)
    {
        return equippedCombos.TryGetValue(category, out var list)
            ? new List<int>(list)
            : new List<int>();
    }

    public bool IsAttackUnlocked(int id, AttackCategory category)
    {
        return unlockedAttacks.TryGetValue(category, out var list) && list.Contains(id);
    }

    #endregion

    #region Modifiers

    public void UnlockAttack(int id, AttackCategory category)
    {
        if (!unlockedAttacks.ContainsKey(category))
            unlockedAttacks[category] = new List<int>();

        if (!unlockedAttacks[category].Contains(id))
            unlockedAttacks[category].Add(id);

        if (!saveData.unlockData.unlockedAttacks.ContainsKey(category))
            saveData.unlockData.unlockedAttacks[category] = new List<int>();
        if (!saveData.unlockData.unlockedAttacks[category].Contains(id))
            saveData.unlockData.unlockedAttacks[category].Add(id);
    }

    public void SetCombo(AttackCategory category, List<int> combo)
    {
        if (!equippedCombos.ContainsKey(category))
            equippedCombos[category] = new List<int>();

        equippedCombos[category] = new List<int>(combo);

        if (!saveData.comboData.equippedCombos.ContainsKey(category))
            saveData.comboData.equippedCombos[category] = new List<int>();

        saveData.comboData.equippedCombos[category] = new List<int>(combo);
    }

    #endregion

    #region Saving and Loading

    public void LoadFromData(PlayerSaveData data)
    {
        saveData = data;

        unlockedAttacks = new Dictionary<AttackCategory, List<int>>(data.unlockData.unlockedAttacks);
        equippedCombos = new Dictionary<AttackCategory, List<int>>(data.comboData.equippedCombos);
    }

    public PlayerSaveData GetDataForSaving()
    {
        UpdateSaveData();
        return saveData;
    }

    public void SaveUnlockedAttacks()
    {
        UpdateSaveData();
        SaveSystem.Save(saveData);
    }

    public void LoadUnlockedAttacks()
    {
        if (PlayerPrefs.HasKey("CombatData"))
        {
            string json = PlayerPrefs.GetString("CombatData");
            var data = JsonUtility.FromJson<PlayerSaveData>(json);
            LoadFromData(data);
        }
    }

    #endregion

    public int Currency => saveData.playerStats.money;

    public bool SpendCurrency(int amount)
    {
        if (saveData.playerStats.money >= amount)
        {
            saveData.playerStats.money -= amount;
            return true;
        }
        return false;
    }

    public void AddCurrency(int amount)
    {
        saveData.playerStats.money += amount;
    }

    private void SetDefaultAttacks()
    {
        UnlockAttack(0, AttackCategory.FistKick);
        UnlockAttack(1, AttackCategory.FistKick);
        UnlockAttack(2, AttackCategory.FistKick);
        UnlockAttack(3, AttackCategory.FistKick);
        UnlockAttack(4, AttackCategory.Dagger);
        UnlockAttack(5, AttackCategory.Dagger);
        UnlockAttack(6, AttackCategory.Dagger);
        UnlockAttack(7, AttackCategory.Dagger);
        UnlockAttack(8, AttackCategory.Gun);

        SetCombo(AttackCategory.FistKick, new List<int> { 0, 1 });
        SetCombo(AttackCategory.Dagger, new List<int> { 4, 5 });
        SetCombo(AttackCategory.Gun, new List<int> { 8 });
    }
}
