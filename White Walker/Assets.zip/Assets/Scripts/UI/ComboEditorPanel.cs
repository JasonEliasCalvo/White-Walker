using System.Collections.Generic;
using System.Linq;
using UnityEngine;


public class ComboEditorPanel : MonoBehaviour
{
    public static ComboEditorPanel Instance;

    [SerializeField] private GameObject attackSlotPrefab;
    [SerializeField] private Transform comboSlotsHolder;
    [SerializeField] private CombatDatabaseSO database;

    private CombatData combatData;
    private PlayerSaveData playerData;

    private void Awake() => Instance = this;

    public void OpenEditor(AttackCategory category, CombatData data)
    {
        combatData = data;
        gameObject.SetActive(true);
        LoadAvailableAttacks(category);
        // Puedes guardar `newAttackID` si quieres auto asignarlo en el combo
    }

    private void LoadAvailableAttacks(AttackCategory category)
    {
        foreach (Transform child in comboSlotsHolder)
            Destroy(child.gameObject);

        List<AttackBase> attacks = CombatManager.Instance.GetAttacksByCategory(category);

        foreach (var atk in attacks)
        {
            if (combatData.IsAttackUnlocked(atk.id, category))
            {
                var go = Instantiate(attackSlotPrefab, comboSlotsHolder);
                go.GetComponent<ComboSlot>().Init(atk);
            }
        }
    }

    void SaveCombo(AttackCategory category, List<AttackBase> selectedAttacks)
    {
        List<int> ids = selectedAttacks.Select(a => a.id).ToList();
        playerData.comboData.equippedCombos[category] = ids;

        SaveSystem.Save(playerData);
    }

    public void Close()
    {
        gameObject.SetActive(false);
    }
}
