using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class AttackShopPanelUI : MonoBehaviour
{
    [SerializeField] private ComboEditorPanel comboEditor;

    [SerializeField] private Transform buttonsContainer;
    [SerializeField] private GameObject attackButtonPrefab;
    [SerializeField] private AttackDetailPanelUI detailPanel;

    private CombatData combatData;
    private CombatDatabaseSO combatDatabase;
    private AttackBase selectedAttack;
    private AttackCategory currentCategory;

    [SerializeField] private GameObject equipConfirmPanel;
    [SerializeField] private Button confirmEquipButton;
    [SerializeField] private Button cancelEquipButton;
    [SerializeField] private TextMeshProUGUI moneyText;

    private void Awake()
    {
        confirmEquipButton.onClick.AddListener(() =>
        {
            equipConfirmPanel.SetActive(false);
            comboEditor.OpenEditor(currentCategory, combatData);
            gameObject.SetActive(false);
        });

        cancelEquipButton.onClick.AddListener(() =>
        {
            equipConfirmPanel.SetActive(false);
        });


    }

    public void Setup(CombatData combatData)
    {
        this.combatData = combatData;
    }


    public void DisplayAttacks(List<AttackBase> attacks, AttackCategory category)
    {
        ClearSlots();
        currentCategory = category;

        foreach (var attack in attacks)
        {
            GameObject slotObj = Instantiate(attackButtonPrefab, buttonsContainer);
            AttackButtonUI slot = slotObj.GetComponent<AttackButtonUI>();

            bool isUnlocked = combatData.IsAttackUnlocked(attack.id, category);

            slot.Setup(attack, isUnlocked, (selectedAttack) =>
            {
                this.selectedAttack = selectedAttack; // Guardar el seleccionado
                detailPanel.ShowAttack(selectedAttack, isUnlocked);
            });
        }
    }

    public void TryBuyAttack(AttackBase attack)
    {
        AttackCategory category = attack.category;

        if (combatData.IsAttackUnlocked(attack.id, category)) return;

        if (!combatData.SpendCurrency(attack.cost)) return;

        combatData.UnlockAttack(attack.id, category);
        combatData.SaveUnlockedAttacks();
        GameManager.instance.SaveGame();

        DisplayAttacks(GetAttacksByCategory(category), category);
        detailPanel.ShowAttack(attack, true);

        OpenEquipConfirmation(category);
    }

    private void OpenEquipConfirmation(AttackCategory category)
    {
        equipConfirmPanel.SetActive(true);
    }

    private List<AttackBase> GetAttacksByCategory(AttackCategory category)
    {
        return CombatManager.Instance.GetAttacksByCategory(category);
    }

    private void ClearSlots()
    {
        foreach (Transform child in buttonsContainer)
            Destroy(child.gameObject);
    }
}
