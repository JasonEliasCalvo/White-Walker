using System;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class AttackButtonUI : MonoBehaviour
{
    [SerializeField] private TextMeshProUGUI attackNameText;
    private Button button;

    private AttackBase currentAttack;
    private bool isUnlocked;
    private Action<AttackBase> onSelect;

    public void Awake()
    {
        button = GetComponent<Button>();
    }
    public void Setup(AttackBase attack, bool unlocked, Action<AttackBase> onSelectCallback)
    {
        currentAttack = attack;
        isUnlocked = unlocked;
        onSelect = onSelectCallback;

        attackNameText.text = unlocked ? attack.attackName : "???";

        button.onClick.RemoveAllListeners();
        button.onClick.AddListener(() => onSelect?.Invoke(currentAttack));
    }

    public bool IsUnlocked() => isUnlocked;
}
