using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class AttackDetailPanelUI : MonoBehaviour
{
    [SerializeField] private TextMeshProUGUI attackNameText;
    [SerializeField] private TextMeshProUGUI damageText;
    [SerializeField] private TextMeshProUGUI costText;
    [SerializeField] private TextMeshProUGUI effectsText;
    [SerializeField] private Button buyButton;

    private AttackBase currentData;
    private AttackShopPanelUI parentPanel;
    private bool isUnlocked;

    public void Setup(AttackShopPanelUI shopPanel)
    {
        parentPanel = shopPanel;
        buyButton.onClick.AddListener(OnBuyButtonClicked);
        gameObject.SetActive(false); // Ocultar inicialmente
    }

    public void ShowAttack(AttackBase attack, bool unlocked)
    {
        currentData = attack;
        isUnlocked = unlocked;

        attackNameText.text = isUnlocked ? attack.attackName : "???";
        damageText.text = isUnlocked ? attack.damage.ToString() : "---";
        costText.text = isUnlocked ? attack.cost.ToString() : "---";
        effectsText.text = isUnlocked ? string.Join(", ", attack.effects) : "---";

        buyButton.interactable = !isUnlocked;
        buyButton.gameObject.SetActive(!isUnlocked); // Ocultar bot�n si ya est� comprado

        gameObject.SetActive(true); // Mostrar panel si estaba oculto
    }

    private void OnBuyButtonClicked()
    {
        if (currentData != null && !isUnlocked)
        {
            parentPanel.TryBuyAttack(currentData);
        }
    }
}
