using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoBehaviour
{
    public delegate void DelegatedGameStates();
    public DelegatedGameStates eventGameStart;
    public DelegatedGameStates eventGameEnd;
    public DelegatedGameStates eventHackingMiniGameStart;
    public DelegatedGameStates eventHackingMiniGameReset;
    public DelegatedGameStates eventHackingMiniGameEnd;
    public static GameManager instance;

    public CombatData combatData;

    private PlayerSaveData currentData;

    private Timer timer;
    [SerializeField] float initiateTime;

    public PlayerSaveData CurrentData { get => currentData; set => currentData = value; }

    private void Awake()
    {
        if (instance == null)
        {
            instance = this;
        }
        else
        {
            Destroy(gameObject);
        }

        GamePrepate();
    }

    public void Start()
    {
        GamePrepate();
    }

    public void GamePrepate()
    {
        currentData = SaveSystem.Load();
        combatData.Initialize(currentData);

        timer = FindAnyObjectByType<Timer>();
        Invoke(nameof(GameStart), 0.2f);
    }

    public void SaveGame()
    {
        SaveSystem.Save(CurrentData);
    }

    public void LoadGame()
    {
        CurrentData = SaveSystem.Load();
        combatData.LoadFromData(CurrentData);
    }

    public void OnClick_SaveButton()
    {
        SaveGame();
    }


    public void GameStart()
    {
        eventGameStart?.Invoke();
    }

    public void GamePause()
    {

    }
    public void GameResume()
    {

    }

    public void OnAttackPurchased(int id, AttackCategory category)
    {
        combatData.UnlockAttack(id, category);
        combatData.SaveUnlockedAttacks();
    }

    public void EquipCombo(AttackCategory category, List<int> attackIDs)
    {
        currentData.comboData.equippedCombos[category] = new List<int>(attackIDs);
        SaveSystem.Save(currentData);
    }

    public void HackingMiniGameStart()
    {
        Debug.Log("initiateTime: " + initiateTime);
        timer.eventEndTime += ResetHackingMiniGame;
        timer.Initiate(initiateTime);
        eventHackingMiniGameStart?.Invoke();
    }

    public void ResetHackingMiniGame()
    {
        eventHackingMiniGameReset?.Invoke();
    }

    public void HackingMiniGameEnd()
    {
        eventHackingMiniGameEnd?.Invoke();
    }

    public void GameEnd()
    {
        eventGameEnd?.Invoke();
    }

    public Timer GetTimer()
    {
        return timer;
    }
}
